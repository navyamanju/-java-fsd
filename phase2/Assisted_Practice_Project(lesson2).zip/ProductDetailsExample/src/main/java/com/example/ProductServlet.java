package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// Database connection details
  
    
    
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	  
		    // Retrieve the product details from the database
		    try  (Connection con=DBConnection.getConnection()){
		    	  String productIdStr = request.getParameter("productId");
		          if (productIdStr != null && !productIdStr.isEmpty()) {
		          int productId = Integer.parseInt(productIdStr);
		    
		        String query = "SELECT * FROM products where id=? ";
		        PreparedStatement statement = con.prepareStatement(query);
		       
				statement.setInt(1,productId);

		        ResultSet rs = statement.executeQuery();

		        // Display the product details
		        response.setContentType("text/html");
		    	PrintWriter out=response.getWriter();
		        out.println("<html><body>");
		        out.println("<h2>Product Details</h2>");
		        if (rs.next()) {
		            int id = rs.getInt("id");
		            String name = rs.getString("name");
		            double price = rs.getDouble("price");
		            out.println("<table border=2>");
		            out.println("<tr><th>ID</th><th>Name</th><th>Price</th></tr>");
		            out.println("<tr>");
		            out.println("<td>" + id + "</td>");
		            out.println("<td>" + name + "</td>");
		            out.println("<td>" + price + "</td>");
		            out.println("</tr>");
		            
		        } else {
		            out.println("<p>Product not found</p>");
		        }

		        out.println("</table>");
		      con.close();
		    }
		} catch (SQLException e) {
		    e.printStackTrace();
		       
		      
		}
  }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
        }
	}


