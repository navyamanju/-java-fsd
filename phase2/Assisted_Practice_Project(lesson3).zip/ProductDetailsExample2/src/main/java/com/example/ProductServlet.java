package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		 String name = request.getParameter("name");
	        String description = request.getParameter("description");
	        double price = Double.parseDouble(request.getParameter("price"));

	        // Validate for missing information
	        if (name == null || name.isEmpty() || description == null || description.isEmpty()) {
	            response.setContentType("text/html");
	            PrintWriter out = response.getWriter();
	            out.println("<h3>Error: Name and description are required!</h3>");
	            return;
	        }

	        // Create a Product instance
	        Product product = new Product();
	        product.setName(name);
	        product.setDescription(description);
	        product.setPrice(price);

	        // Add the product to the database using Hibernate
	        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	        Session session = sessionFactory.openSession();
	        Transaction transaction = session.beginTransaction();
	        try {
	            session.save(product);
	            transaction.commit();
	            response.setContentType("text/html");
	            PrintWriter out = response.getWriter();
	            out.println("<h3>Product added successfully!</h3>");
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	            response.setContentType("text/html");
	            PrintWriter out = response.getWriter();
	            out.println("<h3>Error occurred while adding the product!</h3>");
	        } finally {
	            session.close();
	        }
	}

}
