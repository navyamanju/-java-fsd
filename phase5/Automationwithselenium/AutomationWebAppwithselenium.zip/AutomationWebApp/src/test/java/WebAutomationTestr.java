import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebAutomationTestr {

    public static void main(String[] args) {
        // Set the path to ChromeDriver (or your preferred driver)
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\Desktop\\Assesment\\chromedriver-win32\\chromedriver.exe");

        // Initialize WebDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to the registration page
        driver.get("http://localhost:8080/AutomationWebApp/registration.jsp");

        // Find registration form elements and fill them
        WebElement usernameField = driver.findElement(By.name("username"));
        WebElement passwordField = driver.findElement(By.name("password"));
        WebElement confirmPasswordField = driver.findElement(By.name("confirm_password")); // Add the confirm password field
        WebElement registerButton = driver.findElement(By.name("Register"));

        usernameField.sendKeys("Navya");
        passwordField.sendKeys("navya@123");
        confirmPasswordField.sendKeys("navya@123"); // Fill the confirm password field with the same password
        registerButton.click();

        // Assuming that clicking the registration button redirects to the login page,
        // you can now locate and click the login link
        WebElement loginLink = driver.findElement(By.linkText("log in")); // Change the link text accordingly
        loginLink.click();

        // Close the browser
        // driver.quit();
    }
}
