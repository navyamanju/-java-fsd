
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebAutomationTestl {

    public static void main(String[] args) {
        // Set the path to ChromeDriver (or your preferred driver)
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\Desktop\\Assesment\\chromedriver-win32\\chromedriver.exe");

        // Initialize WebDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to the login page
        driver.get("http://localhost:8080/AutomationWebApp/login.jsp");

        // Find login form elements and fill them
        WebElement usernameField = driver.findElement(By.name("username"));
        WebElement passwordField = driver.findElement(By.name("password"));
        WebElement loginButton = driver.findElement(By.name("Login"));

        usernameField.sendKeys("Navya");
        passwordField.sendKeys("navya@123");
        loginButton.click();

        // Close the browser
        //driver.quit();
    }
}
