package com.example;



import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AuthenticationTest {
    private Authentication authentication;

    @BeforeEach
    public void setUp() {
        // Initialize the Authentication class before each test
        authentication = new Authentication();
    }

    @Test
    public void testLoginSuccessful() {
        // Test the login method with valid credentials
        String validUsername = "johnDoe";
        String validPassword = "password123";

        boolean result = authentication.login(validUsername, validPassword);

        assertTrue(result, "Login should be successful with valid credentials.");
        System.out.println("Login successful for user: " + validUsername);
    }

    @Test
    public void testLoginFailed() {
        // Test the login method with invalid credentials
        String invalidUsername = "invalidUser";
        String invalidPassword = "wrongPassword";

        boolean result = authentication.login(invalidUsername, invalidPassword);

        assertFalse(result, "Login should fail with invalid credentials.");
        
    }


    @Test
    public void testRegisterSuccessful() {
        // Test the register method with a unique username
        String newUsername = "newUser";
        String newPassword = "newPassword";

        boolean result = authentication.register(newUsername, newPassword);

        assertTrue(result, "Registration should be successful with a unique username.");
    }

    @Test
    public void testRegisterFailed() {
        // Test the register method with an existing username
        String existingUsername = "johnDoe";
        String newPassword = "newPassword";

        boolean result = authentication.register(existingUsername, newPassword);

        assertFalse(result, "Registration should fail with an existing username.");
    }

    @Test
    public void testChangePasswordSuccessful() {
        // Test the changePassword method with valid username and new password
        String existingUsername = "johnDoe";
        String newPassword = "newPassword";

        boolean result = authentication.changePassword(existingUsername, newPassword);

        assertTrue(result, "Password change should be successful with a valid username.");
    }

    @Test
    public void testChangePasswordFailed() {
        // Test the changePassword method with an invalid username
        String invalidUsername = "invalidUser";
        String newPassword = "newPassword";

        boolean result = authentication.changePassword(invalidUsername, newPassword);

        assertFalse(result, "Password change should fail with an invalid username.");
    }

    // You can add more test methods for other authentication scenarios as needed

}
