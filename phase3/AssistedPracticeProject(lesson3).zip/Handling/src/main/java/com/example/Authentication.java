package com.example;


public class Authentication {

	  public boolean login(String username, String password) {
	        // Add your login logic here
	        // check if the username and password match with the database

	       
	      
	        if ("johnDoe".equals(username) && "password123".equals(password)) {
	            return true; // Login successful
	        } else {
	            return false; // Login failed
	        }
	    }

	 
	    public boolean register(String username, String password) {
	        // Add your registration logic here
	        //  insert the new user's information into the database

	     
	        if (!isUsernameTaken(username)) {
	            // Registration successful
	            // Insert the user's information into the database
	            return true;
	        } else {
	            // Username already taken, registration failed
	            return false;
	        }
	    }

	    public boolean changePassword(String username, String newPassword) {
	        // Add your change password logic here
	        // For example, update the user's password in the database

	   
	        if (isValidUser(username)) {
	            // Change password successful
	            // Update the user's password in the database
	            return true;
	        } else {
	            // User not found, change password failed
	            return false;
	        }
	    }

	    // Placeholder method for user logout
	    public void logout(String username) {
	        // Add your logout logic here
	        // For example, invalidate the user's session or update their status to "logged out"

	       
	        System.out.println("User " + username + " logged out.");
	    }


	    private boolean isUsernameTaken(String username) {
	        // Your database query to check if the username exists
	  
	    	return "johnDoe".equals(username);
	    }

	   
	    private boolean isValidUser(String username) {
	        // Your database query to check if the user exists
	      
	    	   return "johnDoe".equals(username);
	    }

	   
	}
