package com.example.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/feedback")
public class FeedbackController {

    private final FeedbackRepository feedbackRepository;

    @Autowired
    public FeedbackController(FeedbackRepository feedbackRepository) {
        this.feedbackRepository = feedbackRepository;
    }

    @PostMapping
    public ResponseEntity<String> submitFeedback(@RequestBody Feedback feedback) {
        feedbackRepository.save(feedback);
        return ResponseEntity.ok("Feedback submitted successfully!");
    }
    @GetMapping("/feedback-form")
    public String showFeedbackForm() {
        return "feedback-form"; // This returns the name of the HTML file (without the extension)
    }
    @GetMapping
    public ResponseEntity<Iterable<Feedback>> getAllFeedback() {
        Iterable<Feedback> allFeedback = feedbackRepository.findAll();
        return ResponseEntity.ok(allFeedback);
}
}