package com.example;


public class ProductException extends RuntimeException {

}
