let totalAmount = document.getElementById("total-amount");
let userAmount = document.getElementById("user-amount");
const checkAmountButton = document.getElementById("check-amount");
const totalAmountButton = document.getElementById("total-amount-button");
const productTitle = document.getElementById("product-title");
const vendorName = document.getElementById("vendor-name");
const errorMessage = document.getElementById("budget-error");
const productTitleError = document.getElementById("product-title-error");
const productCostError = document.getElementById("product-cost-error");
const amount = document.getElementById("amount");
const expenditureValue = document.getElementById("expenditure-value");
const balanceValue = document.getElementById("balance-amount");
const list = document.getElementById("list");
let tempAmount = 0;
let totalBudgetValue = amount.innerHTML;
let projectListValue = list.innerHTML;
let balanceLocalStorageValue = balanceValue.innerText;

// Store the values in localStorage
localStorage.setItem("totalBudget", totalBudgetValue.toString());
localStorage.setItem("projectList", projectListValue.toString());
localStorage.setItem("balance", balanceLocalStorageValue);

totalAmountButton.addEventListener("click", () => {
  tempAmount = totalAmount.value;
  if (tempAmount === "" || tempAmount < 0) {
    errorMessage.classList.remove("hide");
  } else {
    errorMessage.classList.add("hide");
    amount.innerHTML = tempAmount;
    balanceValue.innerText = tempAmount - expenditureValue.innerText;
    totalAmount.value = "";
  }
});

const disableButtons = (bool) => {
  let editButtons = document.getElementsByClassName("edit");
  Array.from(editButtons).forEach((element) => {
    element.disabled = bool;
  });
};

const modifyElement = (element, edit = false) => {
  let parentDiv = element.closest(".sublist-content");
  let currentBalance = balanceValue.innerText;
  let currentExpense = expenditureValue.innerText;
  let parentAmount = parentDiv.querySelector(".amount").innerText;
  if (edit) {
    let parentText = parentDiv.querySelector(".product").innerText;
    let parentVendor = parentDiv.querySelector(".vendor").innerText;
    productTitle.value = parentText;
    vendorName.value = parentVendor;
    userAmount.value = parentAmount;
    disableButtons(true);
  }
  balanceValue.innerText = parseInt(currentBalance) + parseInt(parentAmount);
  expenditureValue.innerText =
    parseInt(currentExpense) - parseInt(parentAmount);
  parentDiv.remove();
};

const listCreator = (vendorName, expenseName, expenseValue) => {
    let sublistContent = document.createElement("div");
    sublistContent.classList.add("sublist-content", "flex-space");
    
    let vendorCell = document.createElement("p");
    vendorCell.classList.add("vendor");
    vendorCell.textContent = vendorName;
    sublistContent.appendChild(vendorCell);
    
    let productCell = document.createElement("p");
    productCell.classList.add("product");
    productCell.textContent = expenseName;
    sublistContent.appendChild(productCell);
    
    let amountCell = document.createElement("p");
    amountCell.classList.add("amount");
    amountCell.textContent = expenseValue;
    sublistContent.appendChild(amountCell);
    
    let actionsCell = document.createElement("div");
    actionsCell.classList.add("actions");
    actionsCell.style.display = "flex"; // Set to display inline
    
    let editButton = document.createElement("button");
    editButton.classList.add("fa-solid", "fa-pen-to-square", "edit");
    editButton.style.fontSize = "1.2em";
    editButton.addEventListener("click", () => {
      modifyElement(editButton, true);
    });
    actionsCell.appendChild(editButton);
    
    let deleteButton = document.createElement("button");
    deleteButton.classList.add("fa-solid", "fa-trash-can", "delete");
    deleteButton.style.fontSize = "1.2em";
    deleteButton.addEventListener("click", () => {
      modifyElement(deleteButton);
    });
    actionsCell.appendChild(deleteButton);
    
    sublistContent.appendChild(actionsCell);
  
    list.appendChild(sublistContent);
};
  
checkAmountButton.addEventListener("click", () => {
  if (!userAmount.value || !productTitle.value || !vendorName.value) {
    productTitleError.classList.remove("hide");
    return false;
  }
  disableButtons(false);
  let expenditure = parseInt(userAmount.value);
  let sum = parseInt(expenditureValue.innerText) + expenditure;
  expenditureValue.innerText = sum;
  const totalBalance = tempAmount - sum;
  balanceValue.innerText = totalBalance;
  listCreator(vendorName.value, productTitle.value, userAmount.value);
  productTitle.value = "";
  vendorName.value = "";
  userAmount.value = "";
});
