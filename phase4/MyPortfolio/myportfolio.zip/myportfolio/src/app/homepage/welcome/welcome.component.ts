import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  userEmail!: string; // Declare userEmail property without initialization

  constructor() { }

  ngOnInit() {
    // Assuming you have a way to get the logged-in user's email
    // For example, you might get it from a service or local storage
    // For demonstration purposes, let's assume you store it in localStorage
    this.userEmail = localStorage.getItem('loggedInUserEmail') as string;
  }
}
