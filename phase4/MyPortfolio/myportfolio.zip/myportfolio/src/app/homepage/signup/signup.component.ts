import { Component } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  email: string = '';
  reconfirmedEmail: string = '';
  password: string = '';
  registrationSuccess: boolean = false;
  emailValid: boolean = true;
  passwordValid: boolean = true;
  emailMatch: boolean = true;

  submitForm() {
    // Validate email format
    this.emailValid = this.validateEmail(this.email);

    // Validate password length (adjust as needed)
    this.passwordValid = this.password.length >= 8;

    // Validate matching email and reconfirmed email
    this.emailMatch = this.email === this.reconfirmedEmail;

    if (this.emailValid && this.passwordValid && this.emailMatch) {
      // Perform registration logic here
      // Assuming registration is successful
      this.registrationSuccess = true;
    } else {
      this.registrationSuccess = false;
    }
  }

  validateEmail(email: string): boolean {
    // Basic email format validation using regular expression
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return emailPattern.test(email);
  }
}
