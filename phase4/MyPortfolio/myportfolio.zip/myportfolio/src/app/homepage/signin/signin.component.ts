import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent {
  email: string = '';
  password: string = '';
  loginSuccess: boolean = false;
  emailValid: boolean = true;
  passwordValid: boolean = true;

  constructor(private router: Router) {} // Inject the Router service

  submitForm() {
    // Validate email format
    this.emailValid = this.validateEmail(this.email);

    // Validate password length (adjust as needed)
    this.passwordValid = this.password.length >= 8;

    if (this.emailValid && this.passwordValid) {
      // Perform sign-in logic here
      // Assuming login is successful
      this.loginSuccess = true;

      // Navigate to the welcome page on successful login
      this.router.navigate(['/welcome']);
    } else {
      this.loginSuccess = false;
    }
  }

  validateEmail(email: string): boolean {
    // Basic email format validation using regular expression
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return emailPattern.test(email);
  }
}
