import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  passwordForm: FormGroup;
  passwordChanged: boolean = false;

  constructor(private formBuilder: FormBuilder) {
    this.passwordForm = this.formBuilder.group({
      currentPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  changePassword(): void {
    // Perform password change logic here
    if (this.passwordForm.valid) {
      const currentPassword = this.passwordForm.value.currentPassword;
      const newPassword = this.passwordForm.value.newPassword;
      const confirmPassword = this.passwordForm.value.confirmPassword;

      if (newPassword === confirmPassword) {
        // Change the password and set passwordChanged to true
        this.passwordChanged = true;
        // Additional logic to change the password
      } else {
        // Display an error message if new passwords don't match
        // You can also use a validation pattern for password confirmation
      }
    }
  }
}
