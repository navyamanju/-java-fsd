import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import { EmployeeModel } from '../employee-dashboard/employee-dash board.model';
import { ActivatedRoute ,Router} from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-employee-detail', // Update the selector
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.css']
})
export class EmployeeDetailComponent implements OnInit {

  selectedEmployee: EmployeeModel | undefined;
  updateForm: FormGroup;
  updateSuccessMessage: boolean = false; // Initialize the pro
  showDeleteMessage: boolean = false;
  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private formBuilder: FormBuilder,
    private router: Router,
    private location: Location
  ) {
    this.updateForm = this.formBuilder.group({
      firstName: [''],
      lastName: [''],
      email: ['']
    });
  }

  ngOnInit(): void {
    const employeeId = this.route.snapshot.paramMap.get('id');
    if (employeeId) {
      this.api.getEmployeeById(employeeId).subscribe(data => {
        this.selectedEmployee = data;
        // Update the form values with selected employee data
        this.updateForm.patchValue({
          firstName: data.firstName,
          lastName: data.lastName,
          email: data.email
        });
      });
    }
  }
 
  deleteEmployee(): void {
    const id = this.selectedEmployee?.id;
    if (id !== undefined) {
      this.api.deleteEmploye(id).subscribe(
        () => {
          console.log('Employee deleted successfully');
          this.showDeleteMessage = true; // Show the success message
          // Rest of the code
        },
        error => {
          console.error('Error deleting employee', error);
        }
      );
    }
  }
  updateEmployee(): void {
    if (this.selectedEmployee) {
      const updatedEmployee: EmployeeModel = {
        ...this.selectedEmployee,
        firstName: this.updateForm.value.firstName,
        lastName: this.updateForm.value.lastName,
        email: this.updateForm.value.email
      };

      this.api.UpdateEmploye(this.updateForm.value, this.selectedEmployee!.id).subscribe(
        () => {
          console.log('Employee updated successfully');
          this.updateSuccessMessage = true;// Show the success message
      this.location.go(this.location.path());
          // Optionally, you can display a success message to the user
        },
        error => {
          console.error('Error updating employee', error);
          // Optionally, you can display an error message to the user
        }
      );
    }
   
  }
}




