import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeDetailComponent } from './employee-detail/employee-detail.component';
import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';
import { HomeComponent } from './home/home.component'; // Import HomeComponent
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
  const routes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'home', component: HomeComponent },
    { path: 'admin-dashboard', component: AdminComponent }, // Home component route
    { path: 'dashboard', component: EmployeeDashboardComponent }, // Dashboard component route
    { path: 'employee-details/:id', component: EmployeeDetailComponent },
    { path: 'employee-dashboard', component: EmployeeDashboardComponent }, // Employee Dashboard component route
    
  // Other routes...
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
