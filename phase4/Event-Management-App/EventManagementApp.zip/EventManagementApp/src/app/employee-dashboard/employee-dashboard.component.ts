import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../shared/api.service';
import { EmployeeModel } from './employee-dash board.model';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.css']
})
export class EmployeeDashboardComponent implements OnInit {

formValue !: FormGroup;
employeeModelObj:EmployeeModel=new EmployeeModel();
employeeData !:any;

constructor(private formbuilber: FormBuilder,
private api:ApiService, private router: Router)  {}

ngOnInit(): void {
this.formValue = this.formbuilber.group({
firstName: [''],
lastName: [''],
email :['']


})
this.getAllEmployee();
}

postEmployeeDetails(){
  this.employeeModelObj.firstName= this.formValue.value.firstName;
  this.employeeModelObj.lastName= this.formValue.value.lastName;
  this.employeeModelObj.email= this.formValue.value.email;

  this.api.postEmploye(this.employeeModelObj)
  .subscribe(res=>{
    console.log(res);
    alert("Employee Added Successfully")
    let ref = document.getElementById('cancel')
    ref?.click();
    this.formValue.reset();

  },
  err=>{
    alert("something Went wrong");
  
  })
}
getAllEmployee(){
  this.api.getEmploye()
  .subscribe(res=>{
    this.employeeData=res;
  })

  
}
employeeDetails(id: number) {
  this.router.navigate(['employee-details', id]); // Use 'employee-details/:id'
}


}



  
